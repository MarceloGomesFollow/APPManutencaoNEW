# Sistema de Chamados de Manutenção
## Documentação Técnica Completa

---

### Versão: 2.0
### Data: Junho 2025
### Público: Arquitetos e Desenvolvedores

---

## Índice

1. [Arquitetura do Sistema](#arquitetura-do-sistema)
2. [Estrutura do Banco de Dados](#estrutura-do-banco-de-dados)
3. [Fluxos de Trabalho](#fluxos-de-trabalho)
4. [Segurança](#segurança)
5. [Performance](#performance)
6. [Escalabilidade](#escalabilidade)
7. [Integração com Sistemas Externos](#integração-com-sistemas-externos)
8. [Estrutura do Código](#estrutura-do-código)
9. [Padrões de Desenvolvimento](#padrões-de-desenvolvimento)
10. [Testes](#testes)

---

## Arquitetura do Sistema

### Visão Geral

O Sistema de Chamados de Manutenção segue uma arquitetura em camadas (Layered Architecture) com separação clara de responsabilidades:

```
┌─────────────────────────────────────────┐
│              Frontend Layer             │
│  (HTML5 + CSS3 + JavaScript + Bootstrap) │
├─────────────────────────────────────────┤
│            Presentation Layer           │
│         (Flask Templates + Routes)      │
├─────────────────────────────────────────┤
│             Business Layer              │
│           (Services + Logic)            │
├─────────────────────────────────────────┤
│              Data Layer                 │
│        (Models + SQLAlchemy ORM)        │
├─────────────────────────────────────────┤
│            Database Layer               │
│      (SQLite / PostgreSQL / MySQL)     │
└─────────────────────────────────────────┘
```

### Componentes Principais

#### 1. Frontend Layer
- **Tecnologia**: HTML5, CSS3, JavaScript ES6+, Bootstrap 5
- **Responsabilidade**: Interface do usuário, interações client-side
- **Características**:
  - Design responsivo
  - Progressive Enhancement
  - Acessibilidade (WCAG 2.1)
  - Performance otimizada

#### 2. Presentation Layer
- **Tecnologia**: Flask (Python), Jinja2 Templates
- **Responsabilidade**: Renderização de páginas, roteamento HTTP
- **Componentes**:
  - Routes (endpoints HTTP)
  - Templates (views)
  - Forms (validação)
  - Authentication (controle de acesso)

#### 3. Business Layer
- **Tecnologia**: Python, Flask
- **Responsabilidade**: Lógica de negócio, regras de validação
- **Componentes**:
  - Services (lógica de negócio)
  - Validators (validação de dados)
  - Utilities (funções auxiliares)
  - Email Service (notificações)

#### 4. Data Layer
- **Tecnologia**: SQLAlchemy ORM
- **Responsabilidade**: Mapeamento objeto-relacional, queries
- **Componentes**:
  - Models (entidades)
  - Repositories (acesso a dados)
  - Migrations (versionamento do schema)

#### 5. Database Layer
- **Tecnologia**: SQLite (padrão), PostgreSQL, MySQL
- **Responsabilidade**: Persistência de dados
- **Características**:
  - ACID compliance
  - Backup automático
  - Indexação otimizada

### Padrões Arquiteturais

#### MVC (Model-View-Controller)
```python
# Model (src/models/)
class Chamado(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(200), nullable=False)
    # ...

# View (src/templates/)
# chamado.html - Template Jinja2

# Controller (src/routes/)
@chamado_bp.route('/chamados')
def listar_chamados():
    chamados = Chamado.query.all()
    return render_template('chamados.html', chamados=chamados)
```

#### Repository Pattern
```python
class ChamadoRepository:
    @staticmethod
    def buscar_por_status(status):
        return Chamado.query.filter_by(status=status).all()
    
    @staticmethod
    def buscar_por_periodo(data_inicio, data_fim):
        return Chamado.query.filter(
            Chamado.data_abertura.between(data_inicio, data_fim)
        ).all()
```

#### Service Layer Pattern
```python
class ChamadoService:
    @staticmethod
    def criar_chamado(dados):
        # Validações de negócio
        if not dados.get('titulo'):
            raise ValueError("Título é obrigatório")
        
        # Criar chamado
        chamado = Chamado(**dados)
        db.session.add(chamado)
        db.session.commit()
        
        # Enviar notificação
        NotificationService.notificar_novo_chamado(chamado)
        
        return chamado
```

---

## Estrutura do Banco de Dados

### Diagrama ER

```mermaid
erDiagram
    CHAMADO ||--o{ ANEXO : possui
    CHAMADO ||--o{ HISTORICO_CHAMADO : tem
    CHAMADO }o--|| TURNO : pertence
    CHAMADO }o--|| UNIDADE : pertence
    CHAMADO }o--|| LOCAL_APONTAMENTO : localizado
    CHAMADO }o--|| NAO_CONFORMIDADE : classifica
    CHAMADO }o--|| STATUS_CHAMADO : possui
    
    HISTORICO_NOTIFICACOES }o--|| CHAMADO : referencia
    CONTATO_NOTIFICACAO }o--|| UNIDADE : pertence
    
    CHAMADO {
        int id PK
        string protocolo UK
        string titulo
        text descricao
        enum status
        enum prioridade
        string cliente_nome
        string cliente_email
        string cliente_telefone
        int turno_id FK
        int unidade_id FK
        int local_apontamento_id FK
        int nao_conformidade_id FK
        text observacoes
        text resposta_tecnico
        datetime data_abertura
        datetime data_atualizacao
        datetime data_conclusao
    }
    
    TURNO {
        int id PK
        string nome UK
        time horario_inicio
        time horario_fim
        boolean ativo
        datetime data_criacao
    }
    
    UNIDADE {
        int id PK
        string nome UK
        string codigo
        text descricao
        boolean ativo
        datetime data_criacao
    }
```

### Tabelas Principais

#### tb_chamados
```sql
CREATE TABLE tb_chamados (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    protocolo VARCHAR(20) UNIQUE NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'aberto',
    prioridade VARCHAR(10) DEFAULT 'media',
    cliente_nome VARCHAR(100) NOT NULL,
    cliente_email VARCHAR(100) NOT NULL,
    cliente_telefone VARCHAR(20),
    turno_id INTEGER,
    unidade_id INTEGER,
    local_apontamento_id INTEGER,
    nao_conformidade_id INTEGER,
    observacoes TEXT,
    resposta_tecnico TEXT,
    data_abertura DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_conclusao DATETIME,
    
    FOREIGN KEY (turno_id) REFERENCES tb_turnos(id),
    FOREIGN KEY (unidade_id) REFERENCES tb_unidades(id),
    FOREIGN KEY (local_apontamento_id) REFERENCES tb_locais_apontamento(id),
    FOREIGN KEY (nao_conformidade_id) REFERENCES tb_nao_conformidades(id)
);
```

#### Índices
```sql
-- Índices para performance
CREATE INDEX idx_chamados_status ON tb_chamados(status);
CREATE INDEX idx_chamados_prioridade ON tb_chamados(prioridade);
CREATE INDEX idx_chamados_data_abertura ON tb_chamados(data_abertura);
CREATE INDEX idx_chamados_unidade ON tb_chamados(unidade_id);
CREATE INDEX idx_chamados_turno ON tb_chamados(turno_id);
CREATE INDEX idx_chamados_cliente_email ON tb_chamados(cliente_email);

-- Índice composto para relatórios
CREATE INDEX idx_chamados_status_data ON tb_chamados(status, data_abertura);
CREATE INDEX idx_chamados_unidade_status ON tb_chamados(unidade_id, status);
```

### Relacionamentos

#### One-to-Many
- Unidade → Chamados
- Turno → Chamados
- Chamado → Anexos
- Chamado → Histórico

#### Many-to-One
- Chamados → Status
- Chamados → Prioridade
- Chamados → Local de Apontamento
- Chamados → Não Conformidade

### Constraints e Validações

#### Constraints de Banco
```sql
-- Check constraints
ALTER TABLE tb_chamados ADD CONSTRAINT chk_status 
    CHECK (status IN ('aberto', 'em_andamento', 'aguardando_material', 'concluido'));

ALTER TABLE tb_chamados ADD CONSTRAINT chk_prioridade 
    CHECK (prioridade IN ('baixa', 'media', 'alta'));

ALTER TABLE tb_chamados ADD CONSTRAINT chk_email 
    CHECK (cliente_email LIKE '%@%');

-- Triggers para auditoria
CREATE TRIGGER tr_chamados_update 
    AFTER UPDATE ON tb_chamados
    FOR EACH ROW
    BEGIN
        UPDATE tb_chamados 
        SET data_atualizacao = CURRENT_TIMESTAMP 
        WHERE id = NEW.id;
    END;
```

#### Validações de Aplicação
```python
class Chamado(db.Model):
    # Validações SQLAlchemy
    titulo = db.Column(db.String(200), nullable=False)
    cliente_email = db.Column(db.String(100), nullable=False)
    
    @validates('cliente_email')
    def validate_email(self, key, address):
        if '@' not in address:
            raise ValueError("E-mail inválido")
        return address
    
    @validates('prioridade')
    def validate_prioridade(self, key, prioridade):
        if prioridade not in ['baixa', 'media', 'alta']:
            raise ValueError("Prioridade inválida")
        return prioridade
```

---

## Fluxos de Trabalho

### Fluxo de Abertura de Chamado

```mermaid
flowchart TD
    A[Cliente acessa formulário] --> B[Preenche dados obrigatórios]
    B --> C{Dados válidos?}
    C -->|Não| D[Exibe erros de validação]
    D --> B
    C -->|Sim| E[Upload de arquivos opcional]
    E --> F[Gera protocolo único]
    F --> G[Salva no banco de dados]
    G --> H[Registra no histórico]
    H --> I[Envia notificação por e-mail]
    I --> J[Exibe confirmação para cliente]
    J --> K[Notifica equipe de manutenção]
```

#### Implementação
```python
@chamado_bp.route('/abrir-chamado', methods=['POST'])
def abrir_chamado():
    try:
        # 1. Validar dados
        dados = validar_dados_chamado(request.form)
        
        # 2. Processar uploads
        arquivos = processar_uploads(request.files)
        
        # 3. Gerar protocolo
        protocolo = gerar_protocolo()
        
        # 4. Criar chamado
        chamado = Chamado(protocolo=protocolo, **dados)
        db.session.add(chamado)
        db.session.flush()  # Para obter ID
        
        # 5. Salvar arquivos
        for arquivo in arquivos:
            anexo = Anexo(chamado_id=chamado.id, **arquivo)
            db.session.add(anexo)
        
        # 6. Registrar histórico
        historico = HistoricoChamado(
            chamado_id=chamado.id,
            acao="Chamado aberto",
            usuario="Sistema"
        )
        db.session.add(historico)
        
        # 7. Commit transação
        db.session.commit()
        
        # 8. Enviar notificações (async)
        NotificationService.notificar_novo_chamado(chamado)
        
        return jsonify({
            'success': True,
            'protocolo': protocolo,
            'message': 'Chamado aberto com sucesso'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400
```

### Fluxo de Atualização de Status

```mermaid
flowchart TD
    A[Supervisor acessa painel] --> B[Seleciona chamado]
    B --> C[Altera status]
    C --> D{Status válido?}
    D -->|Não| E[Exibe erro]
    D -->|Sim| F[Atualiza banco de dados]
    F --> G[Registra no histórico]
    G --> H[Atualiza data_atualizacao]
    H --> I{Status = concluído?}
    I -->|Sim| J[Define data_conclusao]
    I -->|Não| K[Envia notificação de atualização]
    J --> K
    K --> L[Atualiza interface em tempo real]
```

### Fluxo de Notificações

```mermaid
flowchart TD
    A[Evento disparado] --> B{Notificações ativas?}
    B -->|Não| C[Log evento]
    B -->|Sim| D[Buscar contatos relevantes]
    D --> E[Gerar template de e-mail]
    E --> F[Enviar e-mail via SMTP]
    F --> G{Envio bem-sucedido?}
    G -->|Sim| H[Registrar sucesso no log]
    G -->|Não| I[Registrar erro no log]
    H --> J[Atualizar estatísticas]
    I --> K[Tentar reenvio após delay]
    K --> F
```

---

## Segurança

### Autenticação e Autorização

#### Modelo de Segurança
```python
# Decorador de autenticação
def supervisor_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('supervisor_logged_in'):
            return redirect(url_for('admin_auth.supervisor_login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_auth.admin_login'))
        return f(*args, **kwargs)
    return decorated_function
```

#### Controle de Sessão
```python
# Configuração de sessão segura
app.config.update(
    SESSION_COOKIE_SECURE=True,      # HTTPS only
    SESSION_COOKIE_HTTPONLY=True,    # Não acessível via JavaScript
    SESSION_COOKIE_SAMESITE='Lax',   # Proteção CSRF
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8)
)
```

### Validação de Entrada

#### Sanitização de Dados
```python
from markupsafe import escape
from bleach import clean

def sanitizar_entrada(texto):
    # Remove HTML malicioso
    texto_limpo = clean(texto, tags=[], strip=True)
    # Escapa caracteres especiais
    return escape(texto_limpo)

# Validação de upload
def validar_arquivo(arquivo):
    # Verificar extensão
    if not allowed_file(arquivo.filename):
        raise ValueError("Tipo de arquivo não permitido")
    
    # Verificar tamanho
    if len(arquivo.read()) > MAX_FILE_SIZE:
        raise ValueError("Arquivo muito grande")
    
    # Verificar conteúdo (magic bytes)
    arquivo.seek(0)
    if not validar_magic_bytes(arquivo):
        raise ValueError("Arquivo corrompido ou malicioso")
```

#### Proteção SQL Injection
```python
# Uso correto do SQLAlchemy ORM
def buscar_chamados_por_cliente(email):
    # CORRETO - Parametrizado
    return Chamado.query.filter(Chamado.cliente_email == email).all()

# INCORRETO - Vulnerável
def buscar_chamados_inseguro(email):
    query = f"SELECT * FROM chamados WHERE cliente_email = '{email}'"
    return db.session.execute(query)
```

### Proteção CSRF

#### Implementação
```python
from flask_wtf.csrf import CSRFProtect

csrf = CSRFProtect(app)

# Em templates
<form method="POST">
    {{ csrf_token() }}
    <!-- campos do formulário -->
</form>

# Em JavaScript
$.ajaxSetup({
    beforeSend: function(xhr, settings) {
        if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type) && !this.crossDomain) {
            xhr.setRequestHeader("X-CSRFToken", $('meta[name=csrf-token]').attr('content'));
        }
    }
});
```

### Logs de Segurança

#### Auditoria
```python
import logging

security_logger = logging.getLogger('security')

def log_security_event(event_type, user, details):
    security_logger.info(
        f"SECURITY_EVENT: {event_type} | "
        f"User: {user} | "
        f"IP: {request.remote_addr} | "
        f"Details: {details}"
    )

# Exemplos de uso
log_security_event("LOGIN_SUCCESS", "supervisor", "Painel acessado")
log_security_event("LOGIN_FAILED", "unknown", "Senha incorreta")
log_security_event("UNAUTHORIZED_ACCESS", "guest", "Tentativa de acesso admin")
```

---

## Performance

### Otimizações de Banco de Dados

#### Queries Otimizadas
```python
# CORRETO - Eager loading
def listar_chamados_otimizado():
    return Chamado.query.options(
        joinedload(Chamado.turno),
        joinedload(Chamado.unidade),
        joinedload(Chamado.local_apontamento)
    ).all()

# INCORRETO - N+1 queries
def listar_chamados_lento():
    chamados = Chamado.query.all()
    for chamado in chamados:
        print(chamado.turno.nome)  # Query adicional para cada chamado
```

#### Paginação Eficiente
```python
def listar_chamados_paginado(page=1, per_page=20):
    return Chamado.query.paginate(
        page=page,
        per_page=per_page,
        error_out=False
    )
```

#### Cache de Queries
```python
from flask_caching import Cache

cache = Cache(app)

@cache.memoize(timeout=300)  # 5 minutos
def obter_estatisticas():
    return {
        'total': Chamado.query.count(),
        'abertos': Chamado.query.filter_by(status='aberto').count(),
        'concluidos': Chamado.query.filter_by(status='concluido').count()
    }
```

### Otimizações Frontend

#### Minificação e Compressão
```python
# Configuração Flask
from flask_compress import Compress

Compress(app)

# Minificação de assets
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 31536000  # 1 ano
```

#### Lazy Loading de Imagens
```javascript
// Intersection Observer para lazy loading
const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src;
            img.classList.remove('lazy');
            observer.unobserve(img);
        }
    });
});

document.querySelectorAll('img[data-src]').forEach(img => {
    imageObserver.observe(img);
});
```

### Monitoramento de Performance

#### Métricas
```python
import time
from functools import wraps

def monitor_performance(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        result = f(*args, **kwargs)
        end_time = time.time()
        
        duration = end_time - start_time
        if duration > 1.0:  # Log queries lentas
            app.logger.warning(
                f"Slow query detected: {f.__name__} took {duration:.2f}s"
            )
        
        return result
    return decorated_function

@monitor_performance
def operacao_complexa():
    # Código da operação
    pass
```

---

## Escalabilidade

### Arquitetura Escalável

#### Separação de Responsabilidades
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Load Balancer │    │   Web Servers   │    │   Database      │
│    (Nginx)      │────│   (Gunicorn)    │────│  (PostgreSQL)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │
                       ┌─────────────────┐
                       │   File Storage  │
                       │     (S3/NFS)    │
                       └─────────────────┘
```

#### Configuração de Load Balancer
```nginx
upstream app_servers {
    server 127.0.0.1:5000;
    server 127.0.0.1:5001;
    server 127.0.0.1:5002;
}

server {
    listen 80;
    
    location / {
        proxy_pass http://app_servers;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

### Cache Distribuído

#### Redis para Sessões
```python
import redis
from flask_session import Session

app.config['SESSION_TYPE'] = 'redis'
app.config['SESSION_REDIS'] = redis.from_url('redis://localhost:6379')
Session(app)
```

#### Cache de Aplicação
```python
from flask_caching import Cache

app.config['CACHE_TYPE'] = 'redis'
app.config['CACHE_REDIS_URL'] = 'redis://localhost:6379'
cache = Cache(app)

@cache.cached(timeout=300, key_prefix='chamados_stats')
def obter_estatisticas_cached():
    return calcular_estatisticas()
```

### Processamento Assíncrono

#### Celery para Tarefas
```python
from celery import Celery

celery = Celery('chamados', broker='redis://localhost:6379')

@celery.task
def enviar_email_async(destinatario, assunto, corpo):
    return email_service.enviar_email(destinatario, assunto, corpo)

# Uso
enviar_email_async.delay('user@example.com', 'Assunto', 'Corpo')
```

---

## Integração com Sistemas Externos

### APIs REST

#### Cliente HTTP Reutilizável
```python
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class APIClient:
    def __init__(self, base_url, timeout=30):
        self.base_url = base_url
        self.session = requests.Session()
        
        # Configurar retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504]
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        self.session.timeout = timeout
    
    def get(self, endpoint, **kwargs):
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        return self.session.get(url, **kwargs)
    
    def post(self, endpoint, **kwargs):
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        return self.session.post(url, **kwargs)
```

### Webhooks

#### Sistema de Webhooks
```python
class WebhookService:
    @staticmethod
    def enviar_webhook(url, evento, dados):
        payload = {
            'evento': evento,
            'timestamp': datetime.utcnow().isoformat(),
            'dados': dados
        }
        
        try:
            response = requests.post(
                url,
                json=payload,
                timeout=10,
                headers={'Content-Type': 'application/json'}
            )
            
            if response.status_code == 200:
                app.logger.info(f"Webhook enviado com sucesso: {url}")
            else:
                app.logger.error(f"Webhook falhou: {url} - {response.status_code}")
                
        except Exception as e:
            app.logger.error(f"Erro ao enviar webhook: {url} - {str(e)}")
```

---

**© 2025 Sistema de Chamados de Manutenção - Documentação Técnica Completa**

*Este documento está sujeito a atualizações. Versão atual: 2.0 - Junho 2025*

