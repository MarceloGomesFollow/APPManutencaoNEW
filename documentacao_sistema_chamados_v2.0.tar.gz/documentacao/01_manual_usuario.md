# Sistema de Chamados de Manutenção
## Manual Completo do Usuário

---

### Versão: 2.0
### Data: Junho 2025
### Desenvolvido por: Manus AI

---

## Índice

1. [Introdução](#introdução)
2. [Visão Geral do Sistema](#visão-geral-do-sistema)
3. [Primeiros Passos](#primeiros-passos)
4. [Manual do Cliente](#manual-do-cliente)
5. [Manual do Supervisor](#manual-do-supervisor)
6. [Manual do Administrador](#manual-do-administrador)
7. [Funcionalidades Avançadas](#funcionalidades-avançadas)
8. [Solução de Problemas](#solução-de-problemas)
9. [Suporte e Contato](#suporte-e-contato)

---

## Introdução

O **Sistema de Chamados de Manutenção** é uma plataforma web completa desenvolvida para gerenciar solicitações de manutenção de forma eficiente e organizada. O sistema permite que clientes abram chamados, supervisores gerenciem o atendimento e administradores configurem o sistema.

### Principais Características

- ✅ **Interface Moderna**: Design responsivo e intuitivo
- ✅ **Múltiplos Perfis**: Cliente, Supervisor e Administrador
- ✅ **Gestão Completa**: Do chamado à conclusão
- ✅ **Notificações**: Sistema de e-mail integrado
- ✅ **Relatórios**: Dashboard com estatísticas em tempo real
- ✅ **Upload de Arquivos**: Suporte a fotos e documentos
- ✅ **Histórico Completo**: Rastreamento de todas as ações

### Benefícios

- **Organização**: Centraliza todas as solicitações de manutenção
- **Eficiência**: Agiliza o processo de atendimento
- **Transparência**: Acompanhamento em tempo real
- **Controle**: Relatórios e estatísticas detalhadas
- **Comunicação**: Notificações automáticas por e-mail

---

## Visão Geral do Sistema

### Arquitetura

O sistema é composto por três módulos principais:

1. **Módulo Cliente**: Para abertura e acompanhamento de chamados
2. **Módulo Supervisor**: Para gerenciamento operacional dos chamados
3. **Módulo Administrador**: Para configuração e parametrização do sistema

### Fluxo de Trabalho

```
Cliente → Abre Chamado → Supervisor → Analisa e Atende → Cliente → Recebe Feedback
    ↓                        ↓                              ↑
Notificação            Atualiza Status                 Notificação
```

### Tecnologias Utilizadas

- **Backend**: Python Flask
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Banco de Dados**: SQLite
- **Notificações**: Sistema de e-mail SMTP
- **Upload**: Suporte a múltiplos formatos de arquivo

---

## Primeiros Passos

### Acessando o Sistema

1. **URL Principal**: Acesse o endereço fornecido pelo administrador
2. **Página Inicial**: Visualize as opções disponíveis
3. **Escolha o Perfil**: Cliente, Supervisor ou Administrador

### Navegação Principal

- **🏠 Início**: Página principal do sistema
- **➕ Abrir Chamado**: Formulário para nova solicitação
- **📊 Relatório**: Estatísticas e dados do sistema
- **👤 Acesso**: Menu para login de Supervisor/Administrador

### Responsividade

O sistema é totalmente responsivo e funciona em:
- 💻 **Desktop**: Experiência completa
- 📱 **Mobile**: Interface adaptada para smartphones
- 📱 **Tablet**: Layout otimizado para tablets




---

## Manual do Cliente

### Abrindo um Chamado

#### Passo 1: Acessar o Formulário
1. Na página inicial, clique em **"Abrir Chamado"**
2. Ou use o menu superior **"Abrir Chamado"**

#### Passo 2: Preencher Dados Pessoais
- **Nome Completo**: Seu nome para identificação
- **E-mail**: Para receber notificações sobre o chamado
- **Telefone**: Contato para emergências (opcional)

#### Passo 3: Informações do Chamado
- **Turno**: Selecione o turno de trabalho
- **Unidade**: Escolha a unidade/setor
- **Local de Apontamento**: Local específico do problema
- **Não Conformidade**: Tipo de problema encontrado

#### Passo 4: Descrição Detalhada
- **Título**: Resumo do problema (obrigatório)
- **Descrição**: Detalhe o problema encontrado
- **Prioridade**: Baixa, Média ou Alta
- **Observações**: Informações adicionais

#### Passo 5: Anexar Arquivos
- **Fotos**: Imagens do problema (JPG, PNG, WebP)
- **Documentos**: PDFs, Word, Excel
- **Vídeos**: MP4, AVI (até 16MB por arquivo)
- **Limite**: Máximo 5 arquivos por chamado

#### Passo 6: Enviar Chamado
1. Revise todas as informações
2. Clique em **"Enviar Chamado"**
3. Anote o número do protocolo gerado

### Acompanhando seu Chamado

#### Status Disponíveis
- 🟢 **Aberto**: Chamado recebido, aguardando análise
- 🟡 **Em Andamento**: Equipe trabalhando na solução
- 🟠 **Aguardando Material**: Dependente de materiais/peças
- ✅ **Concluído**: Problema resolvido

#### Notificações por E-mail
Você receberá e-mails automáticos quando:
- ✅ Chamado for aberto
- ✅ Status for alterado
- ✅ Resposta técnica for adicionada
- ✅ Chamado for concluído

### Visualizando Relatórios

#### Página de Relatórios
1. Acesse **"Relatório"** no menu principal
2. Visualize estatísticas gerais do sistema
3. Gráficos interativos com dados em tempo real

#### Informações Disponíveis
- **Total de Chamados**: Quantidade geral
- **Por Status**: Distribuição por situação
- **Por Prioridade**: Classificação de urgência
- **Por Unidade**: Dados por setor
- **Tendências**: Evolução temporal

---

## Manual do Supervisor

### Acessando o Painel

#### Login do Supervisor
1. Clique em **"Acesso"** no menu superior
2. Selecione **"Supervisor"**
3. Digite a senha fornecida pelo administrador
4. Clique em **"Entrar"**

#### Dashboard Principal
Após o login, você verá:
- **Estatísticas**: Cards com números principais
- **Lista de Chamados**: Todos os chamados do sistema
- **Filtros Avançados**: Para busca específica
- **Ações Rápidas**: Botões para operações comuns

### Gerenciando Chamados

#### Visualização da Lista
A lista de chamados mostra:
- **Protocolo**: Número único do chamado
- **Título**: Resumo do problema
- **Cliente**: Nome e e-mail do solicitante
- **Prioridade**: Nível de urgência
- **Status**: Situação atual
- **Turno/Unidade**: Localização
- **Data**: Quando foi aberto

#### Alterando Status
1. **Localizar o Chamado**: Use filtros se necessário
2. **Selecionar Status**: Dropdown na coluna "Status"
3. **Confirmar**: Status é alterado automaticamente
4. **Notificação**: Cliente recebe e-mail da mudança

#### Adicionando Resposta Técnica
1. **Clicar em "Responder"**: Botão na coluna "Ações"
2. **Escrever Resposta**: Detalhe as ações tomadas
3. **Salvar**: Resposta fica visível para o cliente
4. **E-mail**: Cliente é notificado automaticamente

#### Visualizando Detalhes
1. **Clicar em "Ver"**: Botão na coluna "Ações"
2. **Página Completa**: Todos os dados do chamado
3. **Histórico**: Timeline de todas as ações
4. **Anexos**: Download de arquivos enviados

### Filtros Avançados

#### Tipos de Filtro
- **Status**: Filtrar por situação
- **Prioridade**: Alta, Média, Baixa
- **Turno**: Por período de trabalho
- **Unidade**: Por setor/departamento
- **Data**: Período específico
- **Busca Geral**: Protocolo, título, cliente

#### Usando os Filtros
1. **Expandir Filtros**: Clicar no botão "Filtros Avançados"
2. **Selecionar Critérios**: Escolher os filtros desejados
3. **Aplicar**: Clicar em "Aplicar Filtros"
4. **Limpar**: Botão "Limpar" remove todos os filtros

### Exportação de Dados

#### Exportar Lista
1. **Aplicar Filtros**: Se necessário
2. **Clicar "Exportar"**: Botão na área de filtros
3. **Download**: Arquivo CSV é gerado
4. **Abrir**: Use Excel ou similar para visualizar

---

## Manual do Administrador

### Acessando a Administração

#### Login do Administrador
1. Clique em **"Acesso"** no menu superior
2. Selecione **"Administrador"**
3. Digite a senha de administrador
4. Clique em **"Acessar Administração"**

#### Painel Administrativo
O painel oferece acesso a:
- **Configurações**: Parâmetros do sistema
- **Cadastros**: Turnos, unidades, status, etc.
- **Notificações**: Gerenciamento de e-mails
- **Relatórios**: Estatísticas avançadas

### Gerenciando Cadastros

#### Turnos de Trabalho
**Acessar**: Administração → Turnos
- **Criar**: Adicionar novos turnos
- **Editar**: Modificar turnos existentes
- **Ativar/Desativar**: Controlar disponibilidade

#### Unidades/Setores
**Acessar**: Administração → Unidades
- **Cadastrar**: Novas unidades organizacionais
- **Gerenciar**: Editar ou desativar unidades
- **Organizar**: Manter estrutura atualizada

#### Status de Chamados
**Acessar**: Administração → Status
- **Personalizar**: Criar status específicos
- **Ordenar**: Definir sequência lógica
- **Configurar**: Cores e ícones

#### Locais de Apontamento
**Acessar**: Administração → Locais
- **Mapear**: Todos os locais possíveis
- **Detalhar**: Especificações de cada local
- **Manter**: Lista sempre atualizada

#### Não Conformidades
**Acessar**: Administração → Não Conformidades
- **Classificar**: Tipos de problemas
- **Categorizar**: Grupos de não conformidades
- **Padronizar**: Nomenclatura consistente

### Sistema de Notificações

#### Configuração de E-mail
**Acessar**: Administração → Notificações → Configurações
- **Servidor SMTP**: Configurar servidor de e-mail
- **Credenciais**: Usuário e senha para envio
- **Segurança**: TLS/SSL conforme necessário
- **Teste**: Validar configurações

#### Gerenciamento de Contatos
**Acessar**: Administração → Notificações → Contatos
- **Adicionar**: Novos destinatários
- **Segmentar**: Por unidade ou função
- **Ativar/Desativar**: Controlar recebimento
- **Organizar**: Manter lista atualizada

#### Templates de E-mail
**Acessar**: Administração → Notificações → Templates
- **Personalizar**: Mensagens automáticas
- **Variáveis**: Usar dados dinâmicos
- **Testar**: Enviar e-mails de teste
- **Aprovar**: Validar antes de usar

#### Histórico de Notificações
**Acessar**: Administração → Notificações → Histórico
- **Monitorar**: Todos os e-mails enviados
- **Verificar**: Taxa de sucesso
- **Diagnosticar**: Problemas de envio
- **Estatísticas**: Relatórios de performance


---

## Funcionalidades Avançadas

### Dashboard Interativo

#### Gráficos em Tempo Real
- **Pizza**: Distribuição por status
- **Barras**: Chamados por unidade
- **Linha**: Evolução temporal
- **Métricas**: KPIs principais

#### Filtros Dinâmicos
- **Período**: Selecionar datas específicas
- **Unidade**: Focar em setores
- **Status**: Analisar situações
- **Atualização**: Dados em tempo real

### Sistema de Upload

#### Tipos de Arquivo Suportados
- **Imagens**: JPG, JPEG, PNG, WebP, GIF, BMP
- **Documentos**: PDF, DOC, DOCX, XLS, XLSX
- **Vídeos**: MP4, AVI, MOV
- **Outros**: TXT, CSV

#### Limitações
- **Tamanho**: Máximo 16MB por arquivo
- **Quantidade**: Até 5 arquivos por chamado
- **Segurança**: Validação automática de tipos

### Histórico Completo

#### Timeline de Ações
Cada chamado mantém registro de:
- **Abertura**: Data, hora e dados iniciais
- **Mudanças de Status**: Quem e quando alterou
- **Respostas**: Todas as interações técnicas
- **Notificações**: E-mails enviados
- **Conclusão**: Data e responsável

#### Auditoria
- **Rastreabilidade**: Todas as ações são logadas
- **Responsabilidade**: Identificação de usuários
- **Transparência**: Histórico visível para todos
- **Compliance**: Atende requisitos de auditoria

### Relatórios Avançados

#### Métricas Disponíveis
- **Tempo Médio**: Resolução de chamados
- **Taxa de Conclusão**: Percentual resolvido
- **Distribuição**: Por prioridade, unidade, turno
- **Tendências**: Análise temporal
- **Performance**: Indicadores de eficiência

#### Exportação
- **Formato CSV**: Para análise em Excel
- **Filtros Aplicados**: Dados específicos
- **Dados Completos**: Todas as informações
- **Agendamento**: Relatórios automáticos

---

## Solução de Problemas

### Problemas Comuns

#### Não Consigo Abrir Chamado
**Possíveis Causas:**
- Campos obrigatórios não preenchidos
- Arquivo muito grande (>16MB)
- Tipo de arquivo não suportado
- Conexão com internet instável

**Soluções:**
1. Verificar todos os campos marcados com *
2. Reduzir tamanho dos arquivos
3. Usar formatos suportados
4. Tentar novamente com conexão estável

#### Não Recebo E-mails de Notificação
**Possíveis Causas:**
- E-mail incorreto no cadastro
- Mensagens na caixa de spam
- Servidor de e-mail com problemas
- Configuração de notificações desabilitada

**Soluções:**
1. Verificar e-mail digitado
2. Checar pasta de spam/lixo eletrônico
3. Aguardar alguns minutos
4. Contatar administrador do sistema

#### Login de Supervisor/Admin Não Funciona
**Possíveis Causas:**
- Senha incorreta
- Sessão expirada
- Cache do navegador
- Problema de conectividade

**Soluções:**
1. Verificar senha (case-sensitive)
2. Limpar cache do navegador
3. Tentar em aba anônima/privada
4. Contatar administrador para reset

#### Sistema Lento ou Não Carrega
**Possíveis Causas:**
- Conexão de internet lenta
- Muitos usuários simultâneos
- Problema no servidor
- Cache desatualizado

**Soluções:**
1. Verificar velocidade da internet
2. Aguardar alguns minutos
3. Atualizar página (F5)
4. Limpar cache do navegador

### Códigos de Erro

#### Erro 404 - Página Não Encontrada
- **Causa**: URL incorreta ou página removida
- **Solução**: Verificar endereço ou voltar ao início

#### Erro 500 - Erro Interno do Servidor
- **Causa**: Problema no servidor
- **Solução**: Aguardar ou contatar suporte

#### Erro 403 - Acesso Negado
- **Causa**: Sem permissão para acessar
- **Solução**: Fazer login ou contatar administrador

### Dicas de Performance

#### Para Melhor Experiência
- **Navegador Atualizado**: Use versões recentes
- **JavaScript Habilitado**: Necessário para funcionalidades
- **Cookies Permitidos**: Para manter sessão
- **Popup Desbloqueado**: Para downloads e notificações

#### Navegadores Recomendados
- ✅ **Chrome**: Versão 90+
- ✅ **Firefox**: Versão 88+
- ✅ **Safari**: Versão 14+
- ✅ **Edge**: Versão 90+

---

## Suporte e Contato

### Canais de Suporte

#### Suporte Técnico
- **E-mail**: suporte@sistema-chamados.com
- **Telefone**: (11) 99999-9999
- **Horário**: Segunda a Sexta, 8h às 18h

#### Documentação Online
- **Manual Completo**: Disponível no sistema
- **FAQ**: Perguntas frequentes
- **Tutoriais**: Vídeos explicativos
- **Atualizações**: Notas de versão

### Treinamento

#### Para Usuários
- **Sessão Inicial**: 1 hora de treinamento
- **Material**: Manual e vídeos
- **Prática**: Ambiente de teste
- **Certificação**: Opcional

#### Para Administradores
- **Treinamento Avançado**: 4 horas
- **Configuração**: Setup completo
- **Manutenção**: Procedimentos
- **Troubleshooting**: Solução de problemas

### Atualizações do Sistema

#### Cronograma
- **Manutenções**: Domingos, 2h às 6h
- **Atualizações**: Mensais
- **Correções**: Conforme necessário
- **Notificação**: E-mail prévio

#### Novidades
- **Funcionalidades**: Melhorias contínuas
- **Interface**: Aprimoramentos visuais
- **Performance**: Otimizações
- **Segurança**: Patches regulares

---

## Anexos

### Glossário de Termos

- **Chamado**: Solicitação de manutenção
- **Protocolo**: Número único de identificação
- **Status**: Situação atual do chamado
- **Prioridade**: Nível de urgência
- **Não Conformidade**: Tipo de problema
- **Timeline**: Histórico cronológico
- **Dashboard**: Painel de controle
- **Template**: Modelo de e-mail

### Atalhos de Teclado

- **Ctrl + N**: Novo chamado
- **Ctrl + F**: Buscar
- **Ctrl + R**: Atualizar página
- **Esc**: Fechar modal
- **Enter**: Confirmar ação

### Formatos de Data

- **Padrão**: DD/MM/AAAA
- **Hora**: HH:MM
- **Completo**: DD/MM/AAAA HH:MM

---

**© 2025 Sistema de Chamados de Manutenção - Desenvolvido por Manus AI**

*Este manual está sujeito a atualizações. Versão atual: 2.0 - Junho 2025*

