# Sistema de Chamados de Manutenção
## Guia de Instalação e Configuração

---

### Versão: 2.0
### Data: Junho 2025
### Público: Administradores de Sistema

---

## Índice

1. [Requisitos do Sistema](#requisitos-do-sistema)
2. [Instalação](#instalação)
3. [Configuração Inicial](#configuração-inicial)
4. [Configuração de E-mail](#configuração-de-e-mail)
5. [Configuração de Banco de Dados](#configuração-de-banco-de-dados)
6. [Deploy em Produção](#deploy-em-produção)
7. [Manutenção](#manutenção)
8. [Backup e Recuperação](#backup-e-recuperação)
9. [Monitoramento](#monitoramento)
10. [Troubleshooting](#troubleshooting)

---

## Requisitos do Sistema

### Requisitos Mínimos

#### Servidor
- **CPU**: 2 cores, 2.0 GHz
- **RAM**: 4 GB
- **Armazenamento**: 20 GB SSD
- **Rede**: 100 Mbps
- **OS**: Ubuntu 20.04+ / CentOS 8+ / Windows Server 2019+

#### Software
- **Python**: 3.8+
- **Node.js**: 16+ (opcional, para desenvolvimento)
- **Banco de Dados**: SQLite (padrão) / PostgreSQL / MySQL
- **Servidor Web**: Nginx / Apache (produção)
- **SMTP**: Servidor de e-mail configurado

### Requisitos Recomendados

#### Servidor
- **CPU**: 4 cores, 3.0 GHz
- **RAM**: 8 GB
- **Armazenamento**: 50 GB SSD
- **Rede**: 1 Gbps
- **OS**: Ubuntu 22.04 LTS

#### Infraestrutura
- **Load Balancer**: Para alta disponibilidade
- **CDN**: Para arquivos estáticos
- **Backup**: Automático e redundante
- **Monitoramento**: Logs e métricas

---

## Instalação

### Instalação Automática (Recomendada)

#### Usando Docker
```bash
# 1. Clonar repositório
git clone https://github.com/seu-repo/chamados-manutencao.git
cd chamados-manutencao

# 2. Configurar variáveis
cp .env.example .env
nano .env

# 3. Executar com Docker
docker-compose up -d

# 4. Verificar status
docker-compose ps
```

#### Usando Script de Instalação
```bash
# 1. Download do script
wget https://releases.sistema-chamados.com/install.sh
chmod +x install.sh

# 2. Executar instalação
sudo ./install.sh

# 3. Seguir instruções interativas
```

### Instalação Manual

#### Passo 1: Preparar Ambiente
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install python3 python3-pip python3-venv git nginx

# CentOS/RHEL
sudo yum update
sudo yum install python3 python3-pip git nginx
```

#### Passo 2: Clonar Código
```bash
# Criar diretório
sudo mkdir -p /opt/chamados-manutencao
cd /opt/chamados-manutencao

# Clonar repositório
git clone https://github.com/seu-repo/chamados-manutencao.git .

# Definir permissões
sudo chown -R www-data:www-data /opt/chamados-manutencao
```

#### Passo 3: Ambiente Virtual Python
```bash
# Criar ambiente virtual
python3 -m venv venv

# Ativar ambiente
source venv/bin/activate

# Instalar dependências
pip install -r requirements.txt
```

#### Passo 4: Configurar Banco de Dados
```bash
# Executar migrações
python src/main.py db init
python src/main.py db migrate
python src/main.py db upgrade

# Criar dados iniciais
python scripts/seed_data.py
```

#### Passo 5: Configurar Servidor Web
```bash
# Copiar configuração Nginx
sudo cp configs/nginx.conf /etc/nginx/sites-available/chamados
sudo ln -s /etc/nginx/sites-available/chamados /etc/nginx/sites-enabled/

# Testar configuração
sudo nginx -t

# Reiniciar Nginx
sudo systemctl restart nginx
```

---

## Configuração Inicial

### Arquivo de Configuração Principal

#### .env (Variáveis de Ambiente)
```bash
# Configurações Básicas
FLASK_ENV=production
SECRET_KEY=sua-chave-secreta-muito-forte
DEBUG=False

# Banco de Dados
DATABASE_URL=sqlite:///chamados.db
# Para PostgreSQL: postgresql://user:pass@localhost/chamados
# Para MySQL: mysql://user:pass@localhost/chamados

# Servidor
HOST=0.0.0.0
PORT=5000

# Upload de Arquivos
UPLOAD_FOLDER=/opt/chamados-manutencao/uploads
MAX_CONTENT_LENGTH=16777216  # 16MB
ALLOWED_EXTENSIONS=jpg,jpeg,png,gif,pdf,doc,docx,xls,xlsx,mp4,avi

# Senhas de Acesso
SUPERVISOR_PASSWORD=senha-supervisor-segura
ADMIN_PASSWORD=senha-admin-muito-segura

# E-mail (SMTP)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=seu-email@gmail.com
MAIL_PASSWORD=sua-senha-app
MAIL_DEFAULT_SENDER=noreply@sua-empresa.com

# Notificações
NOTIFICACOES_ATIVAS=True
BASE_URL=https://seu-dominio.com

# Logs
LOG_LEVEL=INFO
LOG_FILE=/var/log/chamados/app.log
```

### Configuração de Segurança

#### Gerar Chave Secreta
```python
import secrets
print(secrets.token_hex(32))
```

#### Configurar HTTPS
```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-nginx

# Obter certificado SSL
sudo certbot --nginx -d seu-dominio.com

# Renovação automática
sudo crontab -e
# Adicionar: 0 12 * * * /usr/bin/certbot renew --quiet
```

### Configuração de Permissões

#### Diretórios e Arquivos
```bash
# Permissões do aplicativo
sudo chown -R www-data:www-data /opt/chamados-manutencao
sudo chmod -R 755 /opt/chamados-manutencao

# Diretório de uploads
sudo mkdir -p /opt/chamados-manutencao/uploads
sudo chown -R www-data:www-data /opt/chamados-manutencao/uploads
sudo chmod -R 755 /opt/chamados-manutencao/uploads

# Logs
sudo mkdir -p /var/log/chamados
sudo chown -R www-data:www-data /var/log/chamados
sudo chmod -R 755 /var/log/chamados
```

---

## Configuração de E-mail

### Provedores Suportados

#### Gmail
```bash
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=seu-email@gmail.com
MAIL_PASSWORD=senha-de-app  # Não a senha normal!
```

**Configurar Senha de App:**
1. Acessar Google Account Settings
2. Segurança → Verificação em duas etapas
3. Senhas de app → Gerar nova senha
4. Usar a senha gerada no MAIL_PASSWORD

#### Outlook/Hotmail
```bash
MAIL_SERVER=smtp-mail.outlook.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=seu-email@outlook.com
MAIL_PASSWORD=sua-senha
```

#### Servidor SMTP Personalizado
```bash
MAIL_SERVER=mail.sua-empresa.com
MAIL_PORT=587  # ou 465 para SSL
MAIL_USE_TLS=True  # ou MAIL_USE_SSL=True
MAIL_USERNAME=sistema@sua-empresa.com
MAIL_PASSWORD=senha-do-email
```

### Teste de Configuração

#### Script de Teste
```python
# test_email.py
import os
from src.services.email_service import email_service

# Configurar variáveis de ambiente
os.environ['MAIL_SERVER'] = 'smtp.gmail.com'
os.environ['MAIL_PORT'] = '587'
os.environ['MAIL_USE_TLS'] = 'True'
os.environ['MAIL_USERNAME'] = 'seu-email@gmail.com'
os.environ['MAIL_PASSWORD'] = 'sua-senha-app'

# Testar envio
resultado = email_service.enviar_email(
    destinatario='teste@exemplo.com',
    assunto='Teste de Configuração',
    corpo='Este é um e-mail de teste do sistema.'
)

print(f"Resultado: {'Sucesso' if resultado else 'Falha'}")
```

### Templates de E-mail

#### Personalização
Os templates estão em `src/services/email_templates.py`:

```python
# Exemplo de personalização
TEMPLATE_CHAMADO_ABERTO = """
<h2>Novo Chamado Aberto - #{protocolo}</h2>
<p>Olá {cliente_nome},</p>
<p>Seu chamado foi recebido com sucesso!</p>
<p><strong>Protocolo:</strong> #{protocolo}</p>
<p><strong>Título:</strong> {titulo}</p>
<p><strong>Status:</strong> {status}</p>
<p>Você receberá atualizações por e-mail.</p>
<p>Atenciosamente,<br>Equipe de Manutenção</p>
"""
```

---

## Configuração de Banco de Dados

### SQLite (Padrão)

#### Configuração
```bash
# Já configurado por padrão
DATABASE_URL=sqlite:///chamados.db

# Localização do arquivo
/opt/chamados-manutencao/chamados.db
```

#### Backup SQLite
```bash
# Backup manual
sqlite3 chamados.db ".backup backup_$(date +%Y%m%d_%H%M%S).db"

# Script automático
#!/bin/bash
BACKUP_DIR="/opt/backups/chamados"
mkdir -p $BACKUP_DIR
sqlite3 /opt/chamados-manutencao/chamados.db ".backup $BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).db"
find $BACKUP_DIR -name "backup_*.db" -mtime +7 -delete
```

### PostgreSQL

#### Instalação
```bash
# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib

# Criar banco e usuário
sudo -u postgres psql
CREATE DATABASE chamados;
CREATE USER chamados_user WITH PASSWORD 'senha_forte';
GRANT ALL PRIVILEGES ON DATABASE chamados TO chamados_user;
\q
```

#### Configuração
```bash
DATABASE_URL=postgresql://chamados_user:senha_forte@localhost/chamados
```

#### Backup PostgreSQL
```bash
# Backup
pg_dump -h localhost -U chamados_user chamados > backup_$(date +%Y%m%d_%H%M%S).sql

# Restore
psql -h localhost -U chamados_user chamados < backup_file.sql
```

### MySQL

#### Instalação
```bash
# Ubuntu/Debian
sudo apt install mysql-server

# Configurar
sudo mysql_secure_installation

# Criar banco
mysql -u root -p
CREATE DATABASE chamados CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'chamados_user'@'localhost' IDENTIFIED BY 'senha_forte';
GRANT ALL PRIVILEGES ON chamados.* TO 'chamados_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

#### Configuração
```bash
DATABASE_URL=mysql://chamados_user:senha_forte@localhost/chamados
```

---

## Deploy em Produção

### Usando Gunicorn + Nginx

#### Instalar Gunicorn
```bash
pip install gunicorn
```

#### Configurar Gunicorn
```bash
# gunicorn.conf.py
bind = "127.0.0.1:5000"
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2
max_requests = 1000
max_requests_jitter = 100
preload_app = True
```

#### Service do Systemd
```bash
# /etc/systemd/system/chamados.service
[Unit]
Description=Sistema de Chamados
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/opt/chamados-manutencao
Environment=PATH=/opt/chamados-manutencao/venv/bin
ExecStart=/opt/chamados-manutencao/venv/bin/gunicorn -c gunicorn.conf.py src.main:app
ExecReload=/bin/kill -s HUP $MAINPID
Restart=always

[Install]
WantedBy=multi-user.target
```

#### Ativar Service
```bash
sudo systemctl daemon-reload
sudo systemctl enable chamados
sudo systemctl start chamados
sudo systemctl status chamados
```

### Configuração Nginx

#### /etc/nginx/sites-available/chamados
```nginx
server {
    listen 80;
    server_name seu-dominio.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name seu-dominio.com;

    ssl_certificate /etc/letsencrypt/live/seu-dominio.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/seu-dominio.com/privkey.pem;

    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /opt/chamados-manutencao/src/static;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location /uploads {
        alias /opt/chamados-manutencao/uploads;
        expires 1y;
        add_header Cache-Control "public";
    }
}
```

### Deploy com Docker

#### Dockerfile
```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["gunicorn", "-c", "gunicorn.conf.py", "src.main:app"]
```

#### docker-compose.yml
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/chamados
    volumes:
      - ./uploads:/app/uploads
    depends_on:
      - db

  db:
    image: postgres:13
    environment:
      - POSTGRES_DB=chamados
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/ssl
    depends_on:
      - app

volumes:
  postgres_data:
```


---

## Manutenção

### Rotinas de Manutenção

#### Diária
```bash
# Verificar logs
tail -f /var/log/chamados/app.log

# Verificar espaço em disco
df -h

# Verificar status dos serviços
systemctl status chamados nginx postgresql
```

#### Semanal
```bash
# Backup do banco de dados
./scripts/backup_database.sh

# Limpeza de logs antigos
find /var/log/chamados -name "*.log" -mtime +30 -delete

# Verificar atualizações de segurança
sudo apt update && sudo apt list --upgradable
```

#### Mensal
```bash
# Análise de performance
./scripts/performance_report.sh

# Limpeza de arquivos temporários
./scripts/cleanup_temp_files.sh

# Verificar certificados SSL
certbot certificates
```

### Scripts de Manutenção

#### backup_database.sh
```bash
#!/bin/bash
BACKUP_DIR="/opt/backups/chamados"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# SQLite
if [ -f "/opt/chamados-manutencao/chamados.db" ]; then
    sqlite3 /opt/chamados-manutencao/chamados.db ".backup $BACKUP_DIR/sqlite_backup_$DATE.db"
fi

# PostgreSQL
if command -v pg_dump &> /dev/null; then
    pg_dump -h localhost -U chamados_user chamados > $BACKUP_DIR/postgres_backup_$DATE.sql
fi

# Compactar backups antigos
find $BACKUP_DIR -name "*backup*" -mtime +1 -exec gzip {} \;

# Remover backups muito antigos
find $BACKUP_DIR -name "*backup*.gz" -mtime +30 -delete

echo "Backup concluído: $DATE"
```

#### performance_report.sh
```bash
#!/bin/bash
echo "=== Relatório de Performance - $(date) ==="

echo "1. Uso de CPU e Memória:"
top -bn1 | grep "Cpu\|Mem"

echo "2. Espaço em Disco:"
df -h

echo "3. Status dos Serviços:"
systemctl is-active chamados nginx postgresql

echo "4. Conexões de Rede:"
netstat -tuln | grep :80
netstat -tuln | grep :443
netstat -tuln | grep :5000

echo "5. Logs de Erro (últimas 24h):"
grep -i error /var/log/chamados/app.log | tail -10

echo "6. Tamanho do Banco de Dados:"
if [ -f "/opt/chamados-manutencao/chamados.db" ]; then
    ls -lh /opt/chamados-manutencao/chamados.db
fi
```

### Atualizações do Sistema

#### Processo de Atualização
```bash
# 1. Backup completo
./scripts/backup_database.sh
cp -r /opt/chamados-manutencao /opt/chamados-manutencao.backup

# 2. Parar serviços
sudo systemctl stop chamados

# 3. Atualizar código
cd /opt/chamados-manutencao
git pull origin main

# 4. Atualizar dependências
source venv/bin/activate
pip install -r requirements.txt

# 5. Executar migrações
python src/main.py db upgrade

# 6. Reiniciar serviços
sudo systemctl start chamados
sudo systemctl reload nginx

# 7. Verificar funcionamento
curl -I http://localhost
```

---

## Backup e Recuperação

### Estratégia de Backup

#### Backup Completo
```bash
#!/bin/bash
# backup_completo.sh
BACKUP_ROOT="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$BACKUP_ROOT/completo_$DATE"

mkdir -p $BACKUP_DIR

# 1. Banco de dados
./scripts/backup_database.sh

# 2. Arquivos da aplicação
tar -czf $BACKUP_DIR/aplicacao.tar.gz /opt/chamados-manutencao

# 3. Uploads
tar -czf $BACKUP_DIR/uploads.tar.gz /opt/chamados-manutencao/uploads

# 4. Configurações
cp /etc/nginx/sites-available/chamados $BACKUP_DIR/
cp /etc/systemd/system/chamados.service $BACKUP_DIR/
cp /opt/chamados-manutencao/.env $BACKUP_DIR/

# 5. Logs importantes
cp /var/log/chamados/app.log $BACKUP_DIR/

echo "Backup completo criado em: $BACKUP_DIR"
```

#### Backup Incremental
```bash
#!/bin/bash
# backup_incremental.sh
BACKUP_ROOT="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)
LAST_BACKUP=$(find $BACKUP_ROOT -name "incremental_*" -type d | sort | tail -1)

if [ -z "$LAST_BACKUP" ]; then
    echo "Nenhum backup anterior encontrado. Execute backup completo primeiro."
    exit 1
fi

BACKUP_DIR="$BACKUP_ROOT/incremental_$DATE"
mkdir -p $BACKUP_DIR

# Backup apenas de arquivos modificados
rsync -av --compare-dest=$LAST_BACKUP /opt/chamados-manutencao/ $BACKUP_DIR/

echo "Backup incremental criado em: $BACKUP_DIR"
```

### Recuperação

#### Recuperação Completa
```bash
#!/bin/bash
# restore_completo.sh
BACKUP_DIR=$1

if [ -z "$BACKUP_DIR" ]; then
    echo "Uso: $0 /caminho/para/backup"
    exit 1
fi

# 1. Parar serviços
sudo systemctl stop chamados nginx

# 2. Restaurar aplicação
tar -xzf $BACKUP_DIR/aplicacao.tar.gz -C /

# 3. Restaurar uploads
tar -xzf $BACKUP_DIR/uploads.tar.gz -C /

# 4. Restaurar configurações
cp $BACKUP_DIR/chamados /etc/nginx/sites-available/
cp $BACKUP_DIR/chamados.service /etc/systemd/system/
cp $BACKUP_DIR/.env /opt/chamados-manutencao/

# 5. Restaurar banco de dados
if [ -f "$BACKUP_DIR/sqlite_backup_*.db" ]; then
    cp $BACKUP_DIR/sqlite_backup_*.db /opt/chamados-manutencao/chamados.db
fi

# 6. Ajustar permissões
sudo chown -R www-data:www-data /opt/chamados-manutencao

# 7. Reiniciar serviços
sudo systemctl daemon-reload
sudo systemctl start chamados nginx

echo "Recuperação concluída"
```

### Backup Automático

#### Crontab
```bash
# Editar crontab
sudo crontab -e

# Adicionar entradas
# Backup incremental diário às 2h
0 2 * * * /opt/chamados-manutencao/scripts/backup_incremental.sh

# Backup completo semanal aos domingos às 1h
0 1 * * 0 /opt/chamados-manutencao/scripts/backup_completo.sh

# Limpeza de backups antigos
0 3 * * * find /opt/backups -type d -mtime +30 -exec rm -rf {} \;
```

---

## Monitoramento

### Logs do Sistema

#### Configuração de Logs
```python
# src/config.py
import logging
from logging.handlers import RotatingFileHandler

# Configurar logging
if not app.debug:
    file_handler = RotatingFileHandler(
        '/var/log/chamados/app.log',
        maxBytes=10240000,  # 10MB
        backupCount=10
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.setLevel(logging.INFO)
```

#### Análise de Logs
```bash
# Erros recentes
grep -i error /var/log/chamados/app.log | tail -20

# Acessos por IP
awk '{print $1}' /var/log/nginx/access.log | sort | uniq -c | sort -nr

# Páginas mais acessadas
awk '{print $7}' /var/log/nginx/access.log | sort | uniq -c | sort -nr

# Códigos de status HTTP
awk '{print $9}' /var/log/nginx/access.log | sort | uniq -c | sort -nr
```

### Métricas de Performance

#### Script de Monitoramento
```bash
#!/bin/bash
# monitor.sh

# CPU e Memória
echo "=== CPU e Memória ==="
top -bn1 | head -5

# Espaço em disco
echo "=== Espaço em Disco ==="
df -h | grep -E "/$|/opt"

# Conexões ativas
echo "=== Conexões Ativas ==="
netstat -an | grep :80 | wc -l
netstat -an | grep :443 | wc -l

# Processos do sistema
echo "=== Processos ==="
ps aux | grep -E "gunicorn|nginx|postgres" | grep -v grep

# Tamanho dos logs
echo "=== Tamanho dos Logs ==="
du -sh /var/log/chamados/
du -sh /var/log/nginx/
```

### Alertas

#### Script de Alertas
```bash
#!/bin/bash
# alertas.sh

EMAIL="admin@sua-empresa.com"
THRESHOLD_CPU=80
THRESHOLD_DISK=90
THRESHOLD_MEM=85

# Verificar CPU
CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
if (( $(echo "$CPU_USAGE > $THRESHOLD_CPU" | bc -l) )); then
    echo "ALERTA: CPU em ${CPU_USAGE}%" | mail -s "Alerta CPU - Sistema Chamados" $EMAIL
fi

# Verificar disco
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | cut -d'%' -f1)
if [ $DISK_USAGE -gt $THRESHOLD_DISK ]; then
    echo "ALERTA: Disco em ${DISK_USAGE}%" | mail -s "Alerta Disco - Sistema Chamados" $EMAIL
fi

# Verificar memória
MEM_USAGE=$(free | grep Mem | awk '{printf("%.0f", $3/$2 * 100.0)}')
if [ $MEM_USAGE -gt $THRESHOLD_MEM ]; then
    echo "ALERTA: Memória em ${MEM_USAGE}%" | mail -s "Alerta Memória - Sistema Chamados" $EMAIL
fi

# Verificar se serviços estão rodando
if ! systemctl is-active --quiet chamados; then
    echo "ALERTA: Serviço chamados parado" | mail -s "Alerta Serviço - Sistema Chamados" $EMAIL
fi
```

---

## Troubleshooting

### Problemas Comuns

#### Aplicação Não Inicia
```bash
# Verificar logs
journalctl -u chamados -f

# Verificar configuração
python -c "from src.config import Config; print('Config OK')"

# Verificar dependências
pip check

# Verificar permissões
ls -la /opt/chamados-manutencao/
```

#### Erro de Banco de Dados
```bash
# SQLite - verificar arquivo
ls -la /opt/chamados-manutencao/chamados.db

# PostgreSQL - verificar conexão
psql -h localhost -U chamados_user -d chamados -c "SELECT 1;"

# Executar migrações
python src/main.py db upgrade
```

#### E-mails Não Enviados
```bash
# Testar configuração SMTP
python scripts/test_email.py

# Verificar logs
grep -i mail /var/log/chamados/app.log

# Verificar conectividade
telnet smtp.gmail.com 587
```

#### Performance Lenta
```bash
# Verificar recursos
htop

# Verificar conexões
netstat -tuln

# Verificar logs de erro
tail -f /var/log/nginx/error.log
tail -f /var/log/chamados/app.log
```

### Comandos Úteis

#### Reiniciar Serviços
```bash
sudo systemctl restart chamados
sudo systemctl reload nginx
sudo systemctl restart postgresql
```

#### Verificar Status
```bash
sudo systemctl status chamados
sudo systemctl status nginx
sudo systemctl status postgresql
```

#### Logs em Tempo Real
```bash
tail -f /var/log/chamados/app.log
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

#### Teste de Conectividade
```bash
curl -I http://localhost
curl -I https://seu-dominio.com
wget --spider http://localhost
```

---

**© 2025 Sistema de Chamados de Manutenção - Guia de Instalação e Configuração**

*Este documento está sujeito a atualizações. Versão atual: 2.0 - Junho 2025*

