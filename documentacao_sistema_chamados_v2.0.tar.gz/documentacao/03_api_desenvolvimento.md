# Sistema de Chamados de Manutenção
## Documentação de APIs e Desenvolvimento

---

### Versão: 2.0
### Data: Junho 2025
### Público: Desenvolvedores e Integradores

---

## Índice

1. [Visão Geral da API](#visão-geral-da-api)
2. [Autenticação](#autenticação)
3. [Endpoints da API](#endpoints-da-api)
4. [Modelos de Dados](#modelos-de-dados)
5. [Códigos de Resposta](#códigos-de-resposta)
6. [Exemplos de Uso](#exemplos-de-uso)
7. [SDKs e Bibliotecas](#sdks-e-bibliotecas)
8. [Webhooks](#webhooks)
9. [Rate Limiting](#rate-limiting)
10. [Versionamento](#versionamento)

---

## Visão Geral da API

### Arquitetura REST

A API do Sistema de Chamados segue os princípios REST (Representational State Transfer) e utiliza:

- **Protocolo**: HTTP/HTTPS
- **Formato**: JSON para requisições e respostas
- **Métodos**: GET, POST, PUT, DELETE
- **Autenticação**: Token-based (JWT)
- **Versionamento**: Via header ou URL

### Base URL
```
Produção: https://api.sistema-chamados.com/v1
Desenvolvimento: https://dev-api.sistema-chamados.com/v1
```

### Características

- ✅ **RESTful**: Seguindo padrões REST
- ✅ **JSON**: Formato padrão para dados
- ✅ **CORS**: Suporte a requisições cross-origin
- ✅ **Rate Limiting**: Controle de taxa de requisições
- ✅ **Paginação**: Para listas grandes
- ✅ **Filtros**: Busca e filtragem avançada
- ✅ **Webhooks**: Notificações em tempo real

---

## Autenticação

### Token JWT

#### Obter Token
```http
POST /auth/login
Content-Type: application/json

{
  "username": "supervisor",
  "password": "senha123",
  "type": "supervisor"
}
```

#### Resposta
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expires_in": 3600,
  "user": {
    "id": 1,
    "username": "supervisor",
    "type": "supervisor",
    "permissions": ["read_chamados", "update_chamados"]
  }
}
```

#### Usar Token
```http
GET /chamados
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Tipos de Usuário

#### Supervisor
- **Permissões**: Ler e atualizar chamados
- **Endpoints**: `/chamados/*`, `/relatorios/*`

#### Administrador
- **Permissões**: Acesso completo
- **Endpoints**: Todos os endpoints

#### API Key (Integrações)
```http
GET /chamados
X-API-Key: sua-api-key-aqui
```

---

## Endpoints da API

### Chamados

#### Listar Chamados
```http
GET /chamados
```

**Parâmetros de Query:**
- `page`: Número da página (padrão: 1)
- `limit`: Itens por página (padrão: 20, máximo: 100)
- `status`: Filtrar por status
- `prioridade`: Filtrar por prioridade
- `turno_id`: Filtrar por turno
- `unidade_id`: Filtrar por unidade
- `data_inicio`: Data inicial (YYYY-MM-DD)
- `data_fim`: Data final (YYYY-MM-DD)
- `search`: Busca geral

**Exemplo:**
```http
GET /chamados?status=aberto&prioridade=alta&page=1&limit=10
```

**Resposta:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "protocolo": "2025001",
      "titulo": "Problema na impressora",
      "descricao": "Impressora não está funcionando",
      "status": "aberto",
      "prioridade": "alta",
      "cliente_nome": "João Silva",
      "cliente_email": "joao@empresa.com",
      "turno": {
        "id": 1,
        "nome": "Manhã"
      },
      "unidade": {
        "id": 1,
        "nome": "Administração"
      },
      "data_abertura": "2025-06-18T10:30:00Z",
      "data_atualizacao": "2025-06-18T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 45,
    "pages": 5
  }
}
```

#### Obter Chamado Específico
```http
GET /chamados/{id}
```

**Resposta:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "protocolo": "2025001",
    "titulo": "Problema na impressora",
    "descricao": "Impressora não está funcionando",
    "status": "aberto",
    "prioridade": "alta",
    "cliente_nome": "João Silva",
    "cliente_email": "joao@empresa.com",
    "cliente_telefone": "(11) 99999-9999",
    "turno": {
      "id": 1,
      "nome": "Manhã",
      "horario_inicio": "06:00",
      "horario_fim": "14:00"
    },
    "unidade": {
      "id": 1,
      "nome": "Administração",
      "codigo": "ADM"
    },
    "local_apontamento": {
      "id": 1,
      "nome": "Sala 101"
    },
    "nao_conformidade": {
      "id": 1,
      "nome": "Equipamento com defeito"
    },
    "observacoes": "Urgente - afetando produtividade",
    "resposta_tecnico": "Verificando problema...",
    "data_abertura": "2025-06-18T10:30:00Z",
    "data_atualizacao": "2025-06-18T11:15:00Z",
    "anexos": [
      {
        "id": 1,
        "nome": "foto_problema.jpg",
        "url": "/uploads/foto_problema.jpg",
        "tamanho": 1024000
      }
    ],
    "historico": [
      {
        "id": 1,
        "acao": "Chamado aberto",
        "usuario": "Sistema",
        "data": "2025-06-18T10:30:00Z"
      },
      {
        "id": 2,
        "acao": "Status alterado para 'em_andamento'",
        "usuario": "supervisor",
        "data": "2025-06-18T11:15:00Z"
      }
    ]
  }
}
```

#### Criar Chamado
```http
POST /chamados
Content-Type: application/json

{
  "titulo": "Problema na impressora",
  "descricao": "Impressora não está funcionando",
  "prioridade": "alta",
  "cliente_nome": "João Silva",
  "cliente_email": "joao@empresa.com",
  "cliente_telefone": "(11) 99999-9999",
  "turno_id": 1,
  "unidade_id": 1,
  "local_apontamento_id": 1,
  "nao_conformidade_id": 1,
  "observacoes": "Urgente - afetando produtividade"
}
```

**Resposta:**
```json
{
  "success": true,
  "message": "Chamado criado com sucesso",
  "data": {
    "id": 1,
    "protocolo": "2025001",
    "status": "aberto"
  }
}
```

#### Atualizar Chamado
```http
PUT /chamados/{id}
Content-Type: application/json

{
  "status": "em_andamento",
  "resposta_tecnico": "Verificando problema na impressora. Peças solicitadas."
}
```

#### Upload de Arquivos
```http
POST /chamados/{id}/anexos
Content-Type: multipart/form-data

arquivo: [arquivo binário]
```

### Relatórios

#### Estatísticas Gerais
```http
GET /relatorios/estatisticas
```

**Parâmetros:**
- `data_inicio`: Data inicial
- `data_fim`: Data final
- `unidade_id`: Filtrar por unidade

**Resposta:**
```json
{
  "success": true,
  "data": {
    "total_chamados": 150,
    "chamados_abertos": 25,
    "chamados_andamento": 30,
    "chamados_concluidos": 95,
    "tempo_medio_resolucao": 2.5,
    "por_prioridade": {
      "alta": 20,
      "media": 80,
      "baixa": 50
    },
    "por_unidade": [
      {
        "unidade": "Administração",
        "total": 45
      },
      {
        "unidade": "Produção",
        "total": 105
      }
    ]
  }
}
```

#### Relatório Detalhado
```http
GET /relatorios/detalhado
```

### Configurações

#### Listar Turnos
```http
GET /configuracoes/turnos
```

#### Listar Unidades
```http
GET /configuracoes/unidades
```

#### Listar Status
```http
GET /configuracoes/status
```

#### Listar Locais
```http
GET /configuracoes/locais
```

#### Listar Não Conformidades
```http
GET /configuracoes/nao-conformidades
```

---

## Modelos de Dados

### Chamado
```json
{
  "id": "integer",
  "protocolo": "string",
  "titulo": "string (required, max: 200)",
  "descricao": "text (required)",
  "status": "enum ['aberto', 'em_andamento', 'aguardando_material', 'concluido']",
  "prioridade": "enum ['baixa', 'media', 'alta']",
  "cliente_nome": "string (required, max: 100)",
  "cliente_email": "string (required, email)",
  "cliente_telefone": "string (optional, max: 20)",
  "turno_id": "integer (required)",
  "unidade_id": "integer (required)",
  "local_apontamento_id": "integer (optional)",
  "nao_conformidade_id": "integer (optional)",
  "observacoes": "text (optional)",
  "resposta_tecnico": "text (optional)",
  "data_abertura": "datetime",
  "data_atualizacao": "datetime",
  "data_conclusao": "datetime (optional)"
}
```

### Turno
```json
{
  "id": "integer",
  "nome": "string (required, max: 50)",
  "horario_inicio": "time",
  "horario_fim": "time",
  "ativo": "boolean",
  "data_criacao": "datetime"
}
```

### Unidade
```json
{
  "id": "integer",
  "nome": "string (required, max: 100)",
  "codigo": "string (optional, max: 10)",
  "descricao": "text (optional)",
  "ativo": "boolean",
  "data_criacao": "datetime"
}
```

### Anexo
```json
{
  "id": "integer",
  "chamado_id": "integer",
  "nome_original": "string",
  "nome_arquivo": "string",
  "caminho": "string",
  "tamanho": "integer",
  "tipo_mime": "string",
  "data_upload": "datetime"
}
```

### Histórico
```json
{
  "id": "integer",
  "chamado_id": "integer",
  "acao": "string",
  "detalhes": "text (optional)",
  "usuario": "string",
  "data": "datetime"
}
```

---

## Códigos de Resposta

### Códigos de Sucesso

#### 200 OK
Requisição processada com sucesso.

#### 201 Created
Recurso criado com sucesso.

#### 204 No Content
Requisição processada, sem conteúdo de retorno.

### Códigos de Erro

#### 400 Bad Request
```json
{
  "success": false,
  "error": "bad_request",
  "message": "Dados inválidos",
  "details": {
    "titulo": ["Campo obrigatório"],
    "cliente_email": ["E-mail inválido"]
  }
}
```

#### 401 Unauthorized
```json
{
  "success": false,
  "error": "unauthorized",
  "message": "Token de acesso inválido ou expirado"
}
```

#### 403 Forbidden
```json
{
  "success": false,
  "error": "forbidden",
  "message": "Sem permissão para acessar este recurso"
}
```

#### 404 Not Found
```json
{
  "success": false,
  "error": "not_found",
  "message": "Chamado não encontrado"
}
```

#### 422 Unprocessable Entity
```json
{
  "success": false,
  "error": "validation_error",
  "message": "Erro de validação",
  "details": {
    "turno_id": ["Turno não existe"]
  }
}
```

#### 429 Too Many Requests
```json
{
  "success": false,
  "error": "rate_limit_exceeded",
  "message": "Muitas requisições. Tente novamente em 60 segundos",
  "retry_after": 60
}
```

#### 500 Internal Server Error
```json
{
  "success": false,
  "error": "internal_error",
  "message": "Erro interno do servidor"
}
```

---

## Exemplos de Uso

### Python

#### Instalação
```bash
pip install requests
```

#### Exemplo Básico
```python
import requests
import json

# Configuração
BASE_URL = "https://api.sistema-chamados.com/v1"
API_KEY = "sua-api-key"

headers = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

# Listar chamados
response = requests.get(f"{BASE_URL}/chamados", headers=headers)
chamados = response.json()

print(f"Total de chamados: {len(chamados['data'])}")

# Criar novo chamado
novo_chamado = {
    "titulo": "Problema no ar condicionado",
    "descricao": "Ar condicionado não está gelando",
    "prioridade": "media",
    "cliente_nome": "Maria Santos",
    "cliente_email": "maria@empresa.com",
    "turno_id": 1,
    "unidade_id": 2
}

response = requests.post(
    f"{BASE_URL}/chamados",
    headers=headers,
    data=json.dumps(novo_chamado)
)

if response.status_code == 201:
    chamado_criado = response.json()
    print(f"Chamado criado: {chamado_criado['data']['protocolo']}")
```

#### Classe Helper
```python
class ChamadosAPI:
    def __init__(self, base_url, api_key):
        self.base_url = base_url
        self.headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
    
    def listar_chamados(self, **filtros):
        response = requests.get(
            f"{self.base_url}/chamados",
            headers=self.headers,
            params=filtros
        )
        return response.json()
    
    def obter_chamado(self, chamado_id):
        response = requests.get(
            f"{self.base_url}/chamados/{chamado_id}",
            headers=self.headers
        )
        return response.json()
    
    def criar_chamado(self, dados):
        response = requests.post(
            f"{self.base_url}/chamados",
            headers=self.headers,
            data=json.dumps(dados)
        )
        return response.json()
    
    def atualizar_chamado(self, chamado_id, dados):
        response = requests.put(
            f"{self.base_url}/chamados/{chamado_id}",
            headers=self.headers,
            data=json.dumps(dados)
        )
        return response.json()

# Uso
api = ChamadosAPI("https://api.sistema-chamados.com/v1", "sua-api-key")

# Listar chamados em aberto
chamados_abertos = api.listar_chamados(status="aberto")

# Atualizar status
api.atualizar_chamado(1, {"status": "em_andamento"})
```

### JavaScript/Node.js

#### Instalação
```bash
npm install axios
```

#### Exemplo
```javascript
const axios = require('axios');

class ChamadosAPI {
    constructor(baseURL, apiKey) {
        this.client = axios.create({
            baseURL: baseURL,
            headers: {
                'X-API-Key': apiKey,
                'Content-Type': 'application/json'
            }
        });
    }

    async listarChamados(filtros = {}) {
        try {
            const response = await this.client.get('/chamados', { params: filtros });
            return response.data;
        } catch (error) {
            throw new Error(`Erro ao listar chamados: ${error.message}`);
        }
    }

    async criarChamado(dados) {
        try {
            const response = await this.client.post('/chamados', dados);
            return response.data;
        } catch (error) {
            throw new Error(`Erro ao criar chamado: ${error.message}`);
        }
    }

    async atualizarChamado(id, dados) {
        try {
            const response = await this.client.put(`/chamados/${id}`, dados);
            return response.data;
        } catch (error) {
            throw new Error(`Erro ao atualizar chamado: ${error.message}`);
        }
    }
}

// Uso
const api = new ChamadosAPI('https://api.sistema-chamados.com/v1', 'sua-api-key');

// Exemplo async/await
async function exemplo() {
    try {
        // Listar chamados
        const chamados = await api.listarChamados({ status: 'aberto' });
        console.log(`Chamados em aberto: ${chamados.data.length}`);

        // Criar chamado
        const novoChamado = {
            titulo: 'Problema na rede',
            descricao: 'Internet instável',
            prioridade: 'alta',
            cliente_nome: 'Pedro Silva',
            cliente_email: 'pedro@empresa.com',
            turno_id: 1,
            unidade_id: 1
        };

        const resultado = await api.criarChamado(novoChamado);
        console.log(`Chamado criado: ${resultado.data.protocolo}`);

    } catch (error) {
        console.error('Erro:', error.message);
    }
}

exemplo();
```

### PHP

#### Exemplo
```php
<?php

class ChamadosAPI {
    private $baseUrl;
    private $apiKey;
    
    public function __construct($baseUrl, $apiKey) {
        $this->baseUrl = $baseUrl;
        $this->apiKey = $apiKey;
    }
    
    private function makeRequest($method, $endpoint, $data = null) {
        $url = $this->baseUrl . $endpoint;
        
        $headers = [
            'X-API-Key: ' . $this->apiKey,
            'Content-Type: application/json'
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return [
            'status' => $httpCode,
            'data' => json_decode($response, true)
        ];
    }
    
    public function listarChamados($filtros = []) {
        $query = http_build_query($filtros);
        $endpoint = '/chamados' . ($query ? '?' . $query : '');
        return $this->makeRequest('GET', $endpoint);
    }
    
    public function criarChamado($dados) {
        return $this->makeRequest('POST', '/chamados', $dados);
    }
    
    public function atualizarChamado($id, $dados) {
        return $this->makeRequest('PUT', "/chamados/$id", $dados);
    }
}

// Uso
$api = new ChamadosAPI('https://api.sistema-chamados.com/v1', 'sua-api-key');

// Listar chamados
$response = $api->listarChamados(['status' => 'aberto']);
if ($response['status'] == 200) {
    echo "Chamados encontrados: " . count($response['data']['data']) . "\n";
}

// Criar chamado
$novoChamado = [
    'titulo' => 'Problema no sistema',
    'descricao' => 'Sistema lento',
    'prioridade' => 'media',
    'cliente_nome' => 'Ana Costa',
    'cliente_email' => 'ana@empresa.com',
    'turno_id' => 1,
    'unidade_id' => 1
];

$response = $api->criarChamado($novoChamado);
if ($response['status'] == 201) {
    echo "Chamado criado: " . $response['data']['data']['protocolo'] . "\n";
}
?>
```


---

## SDKs e Bibliotecas

### SDK Python

#### Instalação
```bash
pip install chamados-sdk
```

#### Uso
```python
from chamados_sdk import ChamadosClient

# Inicializar cliente
client = ChamadosClient(
    base_url="https://api.sistema-chamados.com/v1",
    api_key="sua-api-key"
)

# Listar chamados
chamados = client.chamados.list(status="aberto")

# Criar chamado
novo_chamado = client.chamados.create({
    "titulo": "Problema na impressora",
    "descricao": "Não está imprimindo",
    "prioridade": "alta",
    "cliente_nome": "João Silva",
    "cliente_email": "joao@empresa.com",
    "turno_id": 1,
    "unidade_id": 1
})

# Atualizar chamado
client.chamados.update(1, {"status": "em_andamento"})

# Upload de arquivo
with open("foto.jpg", "rb") as arquivo:
    client.chamados.upload_anexo(1, arquivo)
```

### SDK JavaScript

#### Instalação
```bash
npm install @sistema-chamados/sdk
```

#### Uso
```javascript
import { ChamadosClient } from '@sistema-chamados/sdk';

const client = new ChamadosClient({
    baseURL: 'https://api.sistema-chamados.com/v1',
    apiKey: 'sua-api-key'
});

// Listar chamados
const chamados = await client.chamados.list({ status: 'aberto' });

// Criar chamado
const novoChamado = await client.chamados.create({
    titulo: 'Problema na rede',
    descricao: 'Internet instável',
    prioridade: 'alta',
    cliente_nome: 'Maria Santos',
    cliente_email: 'maria@empresa.com',
    turno_id: 1,
    unidade_id: 1
});

// Atualizar chamado
await client.chamados.update(1, { status: 'em_andamento' });
```

### SDK PHP

#### Instalação
```bash
composer require sistema-chamados/sdk
```

#### Uso
```php
use SistemaChamados\Client;

$client = new Client([
    'base_url' => 'https://api.sistema-chamados.com/v1',
    'api_key' => 'sua-api-key'
]);

// Listar chamados
$chamados = $client->chamados()->list(['status' => 'aberto']);

// Criar chamado
$novoChamado = $client->chamados()->create([
    'titulo' => 'Problema no ar condicionado',
    'descricao' => 'Não está gelando',
    'prioridade' => 'media',
    'cliente_nome' => 'Pedro Silva',
    'cliente_email' => 'pedro@empresa.com',
    'turno_id' => 1,
    'unidade_id' => 1
]);
```

---

## Webhooks

### Configuração

#### Registrar Webhook
```http
POST /webhooks
Content-Type: application/json

{
  "url": "https://sua-aplicacao.com/webhook/chamados",
  "eventos": ["chamado.criado", "chamado.atualizado", "chamado.concluido"],
  "ativo": true,
  "secret": "sua-chave-secreta"
}
```

#### Eventos Disponíveis

- `chamado.criado`: Novo chamado criado
- `chamado.atualizado`: Chamado atualizado
- `chamado.concluido`: Chamado concluído
- `chamado.anexo_adicionado`: Novo anexo adicionado
- `notificacao.enviada`: Notificação enviada
- `notificacao.falhou`: Falha no envio de notificação

### Payload do Webhook

#### Estrutura
```json
{
  "evento": "chamado.criado",
  "timestamp": "2025-06-18T10:30:00Z",
  "webhook_id": "webhook_123",
  "data": {
    "chamado": {
      "id": 1,
      "protocolo": "2025001",
      "titulo": "Problema na impressora",
      "status": "aberto",
      "prioridade": "alta",
      "cliente_nome": "João Silva",
      "cliente_email": "joao@empresa.com",
      "data_abertura": "2025-06-18T10:30:00Z"
    }
  }
}
```

### Verificação de Assinatura

#### Python
```python
import hmac
import hashlib

def verificar_webhook(payload, signature, secret):
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(f"sha256={expected_signature}", signature)

# Uso no Flask
@app.route('/webhook/chamados', methods=['POST'])
def webhook_chamados():
    payload = request.get_data(as_text=True)
    signature = request.headers.get('X-Webhook-Signature')
    
    if not verificar_webhook(payload, signature, WEBHOOK_SECRET):
        return 'Assinatura inválida', 401
    
    data = request.get_json()
    
    if data['evento'] == 'chamado.criado':
        # Processar novo chamado
        processar_novo_chamado(data['data']['chamado'])
    
    return 'OK', 200
```

#### Node.js
```javascript
const crypto = require('crypto');

function verificarWebhook(payload, signature, secret) {
    const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(payload)
        .digest('hex');
    
    return crypto.timingSafeEqual(
        Buffer.from(`sha256=${expectedSignature}`),
        Buffer.from(signature)
    );
}

// Uso no Express
app.post('/webhook/chamados', (req, res) => {
    const payload = JSON.stringify(req.body);
    const signature = req.headers['x-webhook-signature'];
    
    if (!verificarWebhook(payload, signature, WEBHOOK_SECRET)) {
        return res.status(401).send('Assinatura inválida');
    }
    
    const { evento, data } = req.body;
    
    if (evento === 'chamado.criado') {
        // Processar novo chamado
        processarNovoChamado(data.chamado);
    }
    
    res.status(200).send('OK');
});
```

---

## Rate Limiting

### Limites Padrão

#### Por Tipo de Usuário
- **API Key**: 1000 requisições/hora
- **Supervisor**: 500 requisições/hora
- **Administrador**: 2000 requisições/hora

#### Por Endpoint
- `GET /chamados`: 100 requisições/minuto
- `POST /chamados`: 20 requisições/minuto
- `PUT /chamados/*`: 50 requisições/minuto
- `POST /*/anexos`: 10 requisições/minuto

### Headers de Resposta

```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1624889400
```

### Tratamento de Rate Limit

#### Python
```python
import time
import requests

def fazer_requisicao_com_retry(url, headers, max_retries=3):
    for tentativa in range(max_retries):
        response = requests.get(url, headers=headers)
        
        if response.status_code == 429:
            retry_after = int(response.headers.get('Retry-After', 60))
            print(f"Rate limit atingido. Aguardando {retry_after} segundos...")
            time.sleep(retry_after)
            continue
        
        return response
    
    raise Exception("Máximo de tentativas atingido")
```

---

## Versionamento

### Estratégia de Versionamento

#### Via URL
```http
GET /v1/chamados
GET /v2/chamados
```

#### Via Header
```http
GET /chamados
Accept: application/vnd.sistema-chamados.v1+json
```

### Versões Disponíveis

#### v1 (Atual)
- **Status**: Estável
- **Suporte**: Até dezembro 2025
- **Recursos**: Todos os endpoints básicos

#### v2 (Beta)
- **Status**: Beta
- **Lançamento**: Setembro 2025
- **Novidades**: GraphQL, WebSockets, Filtros avançados

### Migração entre Versões

#### Guia de Migração v1 → v2
```markdown
## Principais Mudanças

1. **Paginação**: Cursor-based em vez de offset
2. **Filtros**: Sintaxe mais avançada
3. **Webhooks**: Novos eventos disponíveis
4. **Rate Limiting**: Limites ajustados

## Exemplo de Migração

### v1
GET /v1/chamados?page=1&limit=20

### v2
GET /v2/chamados?cursor=eyJpZCI6MjB9&limit=20
```

---

## Ambiente de Desenvolvimento

### Sandbox

#### URL
```
https://sandbox-api.sistema-chamados.com/v1
```

#### Características
- **Dados**: Dados de teste pré-carregados
- **Reset**: Dados resetados diariamente às 2h
- **Rate Limit**: Mais permissivo para testes
- **Webhooks**: Suporte completo

#### Credenciais de Teste
```json
{
  "api_key": "test_sk_1234567890abcdef",
  "supervisor": {
    "username": "supervisor_test",
    "password": "test123"
  },
  "admin": {
    "username": "admin_test",
    "password": "admin123"
  }
}
```

### Ferramentas de Desenvolvimento

#### Postman Collection
```bash
# Importar collection
curl -o chamados-api.postman_collection.json \
  https://api.sistema-chamados.com/docs/postman
```

#### OpenAPI/Swagger
```
https://api.sistema-chamados.com/docs/swagger
```

#### Insomnia
```bash
# Importar workspace
curl -o chamados-api.insomnia.json \
  https://api.sistema-chamados.com/docs/insomnia
```

### Testes Automatizados

#### Python (pytest)
```python
import pytest
import requests

BASE_URL = "https://sandbox-api.sistema-chamados.com/v1"
API_KEY = "test_sk_1234567890abcdef"

@pytest.fixture
def headers():
    return {
        "X-API-Key": API_KEY,
        "Content-Type": "application/json"
    }

def test_listar_chamados(headers):
    response = requests.get(f"{BASE_URL}/chamados", headers=headers)
    assert response.status_code == 200
    
    data = response.json()
    assert data["success"] is True
    assert "data" in data
    assert "pagination" in data

def test_criar_chamado(headers):
    novo_chamado = {
        "titulo": "Teste API",
        "descricao": "Teste de criação via API",
        "prioridade": "media",
        "cliente_nome": "Teste Cliente",
        "cliente_email": "teste@exemplo.com",
        "turno_id": 1,
        "unidade_id": 1
    }
    
    response = requests.post(
        f"{BASE_URL}/chamados",
        headers=headers,
        json=novo_chamado
    )
    
    assert response.status_code == 201
    
    data = response.json()
    assert data["success"] is True
    assert "protocolo" in data["data"]
```

#### JavaScript (Jest)
```javascript
const axios = require('axios');

const BASE_URL = 'https://sandbox-api.sistema-chamados.com/v1';
const API_KEY = 'test_sk_1234567890abcdef';

const client = axios.create({
    baseURL: BASE_URL,
    headers: {
        'X-API-Key': API_KEY,
        'Content-Type': 'application/json'
    }
});

describe('API de Chamados', () => {
    test('deve listar chamados', async () => {
        const response = await client.get('/chamados');
        
        expect(response.status).toBe(200);
        expect(response.data.success).toBe(true);
        expect(response.data).toHaveProperty('data');
        expect(response.data).toHaveProperty('pagination');
    });
    
    test('deve criar chamado', async () => {
        const novoChamado = {
            titulo: 'Teste API',
            descricao: 'Teste de criação via API',
            prioridade: 'media',
            cliente_nome: 'Teste Cliente',
            cliente_email: 'teste@exemplo.com',
            turno_id: 1,
            unidade_id: 1
        };
        
        const response = await client.post('/chamados', novoChamado);
        
        expect(response.status).toBe(201);
        expect(response.data.success).toBe(true);
        expect(response.data.data).toHaveProperty('protocolo');
    });
});
```

---

## Monitoramento e Logs

### Logs de API

#### Estrutura de Log
```json
{
  "timestamp": "2025-06-18T10:30:00Z",
  "request_id": "req_1234567890",
  "method": "POST",
  "endpoint": "/chamados",
  "user_id": "supervisor_123",
  "user_type": "supervisor",
  "ip_address": "192.168.1.100",
  "user_agent": "ChamadosSDK/1.0",
  "status_code": 201,
  "response_time_ms": 150,
  "request_size": 1024,
  "response_size": 512
}
```

### Métricas

#### Disponibilidade
- **SLA**: 99.9% uptime
- **Monitoramento**: 24/7
- **Alertas**: Automáticos

#### Performance
- **Tempo de Resposta**: < 200ms (95th percentile)
- **Throughput**: 1000 req/s
- **Latência**: < 50ms (mediana)

### Status da API

#### Página de Status
```
https://status.sistema-chamados.com
```

#### Webhook de Status
```json
{
  "evento": "api.status_changed",
  "timestamp": "2025-06-18T10:30:00Z",
  "data": {
    "status": "operational",
    "previous_status": "degraded",
    "affected_services": ["api", "webhooks"],
    "message": "Todos os serviços operando normalmente"
  }
}
```

---

## Suporte e Recursos

### Documentação

#### Links Úteis
- **Documentação Completa**: https://docs.sistema-chamados.com
- **Referência da API**: https://api.sistema-chamados.com/docs
- **Exemplos**: https://github.com/sistema-chamados/examples
- **SDKs**: https://github.com/sistema-chamados/sdks

### Suporte Técnico

#### Canais
- **E-mail**: api-support@sistema-chamados.com
- **Discord**: https://discord.gg/sistema-chamados
- **GitHub Issues**: https://github.com/sistema-chamados/api/issues

#### SLA de Suporte
- **Crítico**: 2 horas
- **Alto**: 8 horas
- **Médio**: 24 horas
- **Baixo**: 72 horas

### Comunidade

#### Recursos da Comunidade
- **Fórum**: https://forum.sistema-chamados.com
- **Stack Overflow**: Tag `sistema-chamados`
- **Reddit**: r/SistemaChamados

---

**© 2025 Sistema de Chamados de Manutenção - Documentação de APIs e Desenvolvimento**

*Este documento está sujeito a atualizações. Versão atual: 2.0 - Junho 2025*

